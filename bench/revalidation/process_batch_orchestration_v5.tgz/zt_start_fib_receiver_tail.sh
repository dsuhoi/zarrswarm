#!/bin/bash
set -euo pipefail
root_dir=/home/d.sukhorukov/zt_ms/receiver_fix_tail_20261005
mkdir -p "$root_dir/src"
tar -xzf /home/d.sukhorukov/zt_ms/receiver_fix_20261005/process_receiver_fixed_source_v5.tgz -C "$root_dir/src"
export PYTHONPATH="$root_dir/src" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONUNBUFFERED=1
export ZT_SCAN_WORKERS=2 ZT_KEEP_LOGS=1 ZT_HASH_CACHE=/home/d.sukhorukov/zt_ms/hashcache
export ZT_SIM_ROOT="$root_dir/work"
cd "$root_dir/src"
exec /home/d.sukhorukov/zt_venv/bin/python sim/e_hetero.py /home/d.sukhorukov/zt_ms/variants_month --procs --peers 36 --boot 3 --nat 0.3 --rate-mbps 1 --placement sat --stations 22 --traces bench/sat_traces_meteor.json --covers jlps,bytes --rep-start 7 --reps 10 --out "$root_dir/results.json"
