import json,os,signal,time,shutil
from datetime import datetime,timezone
from pathlib import Path
root=Path('/home/d.sukhorukov/zt_ms/receiver_fix_20261005')
pid=int((root/'run.pid').read_text())
def args_of(pid):
    p=Path('/proc')/str(pid)
    assert p.stat().st_uid==os.getuid(),pid
    return (p/'cmdline').read_bytes().decode().rstrip('\0').split('\0')
args=args_of(pid)
assert args[args.index('--out')+1]==str(root/'results.json') and 'sim/e_hetero.py' in args,args
assert (Path('/proc')/str(pid)/'cwd').resolve()==root/'src'
start=(Path('/proc')/str(pid)/'stat').read_text().split(') ')[1].split()[19]
while True:
    try:
        data=json.loads((root/'results.json').read_text())
        whole=[r for r in data['rows'] if r['rep']<7]
        if len(whole)==63: break
    except (OSError,json.JSONDecodeError): pass
    assert Path('/proc',str(pid)).exists(),'primary exited before seven placements'
    time.sleep(2)
assert all(r.get('coverage')==1 and r.get('state')=='done' and r.get('value_check')=='exact' for r in whole)
shutil.copyfile(root/'results.json',root/'results_primary_interrupted.json')
assert args_of(pid)==args
assert (Path('/proc')/str(pid)/'stat').read_text().split(') ')[1].split()[19]==start
os.kill(pid,signal.SIGTERM)
time.sleep(1)
children=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        a=args_of(int(p.name))
        if '--home' not in a or 'zarr_torrent.cli' not in a or 'node' not in a:continue
        home=Path(a[a.index('--home')+1]).resolve()
        if not home.is_relative_to(root/'work'):continue
        children.append((int(p.name),a,str(home)))
    except (OSError,ValueError,AssertionError):pass
for child,a,home in children:
    try:
        assert args_of(child)==a
        os.kill(child,signal.SIGTERM)
    except (OSError,AssertionError):pass
time.sleep(2)
for child,a,home in children:
    try:
        if args_of(child)==a:os.kill(child,signal.SIGKILL)
    except (OSError,AssertionError):pass
data['rows']=whole
(root/'results_primary_complete.json').write_text(json.dumps(data,indent=1)+'\n')
record={'recorded_utc':datetime.now(timezone.utc).isoformat(),'predetermined_split':[list(range(7)),[7,8,9]],'primary_full_exact_answers':63,'primary_controller_pid':pid,'primary_args':args,'task_children_signalled':[{'pid':p,'home':h} for p,a,h in children],'interrupted_raw':'results_primary_interrupted.json','completed_prefix':'results_primary_complete.json'}
(root/'batch_split_v5.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
