"""Known source quantum versus an independently fitted step; no estimator tuning.

Run: python bench/identity_boundary.py --out bench/revalidation/identity_boundary_v7.json
These synthetic counterexamples measure an inference limit, not provider prevalence.
"""
import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from zarr_torrent import codec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    assert codec.VALUE_ID == "lattice"
    result = {"started_utc": datetime.now(timezone.utc).isoformat(),
              "estimator": codec.ESTIMATOR, "numpy": np.__version__,
              "source_sha256": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
                                for p in ("zarr_torrent/codec.py", "bench/identity_boundary.py")},
              "protocol": {"source_quantum": 1, "observed_code_strides": [1, 2, 4, 8, 16],
                           "distinct_values": [2, 4, 16, 256], "dtype": "float32",
                           "values": "arange(distinct_values) * observed_code_stride",
                           "change": "add exactly one source count to the first cell",
                           "selection": "All 20 combinations; no fitting changes or omitted cases."}}
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n")  # protocol before executing cases
    cases = []
    for stride in result["protocol"]["observed_code_strides"]:
        for count in result["protocol"]["distinct_values"]:
            a = np.arange(count, dtype="f4") * stride
            b = a.copy()
            b[0] += 1
            va, vb = codec.vcid_of(a), codec.vcid_of(b)
            before, after = codec.lattice_of(a), codec.lattice_of(b)
            codec.VALUE_ID = "exact"
            try:
                exact_match = codec.same_vcid(codec.vcid_of(a), codec.vcid_of(b))
            finally:
                codec.VALUE_ID = "lattice"
            cases.append({"observed_code_stride": stride, "distinct_values": count,
                          "fit_before": before, "fit_after": after,
                          "identity_before": va, "identity_after": vb,
                          "lattice_accepts_changed_cell": codec.same_vcid(va, vb),
                          "exact_accepts_changed_cell": exact_match})
    assert any(c["lattice_accepts_changed_cell"] for c in cases)
    assert not any(c["exact_accepts_changed_cell"] for c in cases)
    assert not any(c["lattice_accepts_changed_cell"] for c in cases if c["observed_code_stride"] == 1)
    result.update(cases=cases, completed_utc=datetime.now(timezone.utc).isoformat())
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"cases": len(cases), "accepted_source_count_changes":
                      sum(c["lattice_accepts_changed_cell"] for c in cases),
                      "exact_accepted_changes": 0}))


if __name__ == "__main__":
    main()
